Dataset
Apnea-ECG Dataset(public dataset) and FAH-ECG Dataset(real clinical dataset)

Usage
Download the dataset Apnea-ECG
Run Preprocessing.py to get a file named apnea-ecg.pkl
Per-segment classification
Run RAFNet.py
Per-recording classification
Run evaluate.py
The performance is shown in table_RAFNet.csv


Requirements
Python==3.6 Keras==2.3.1 TensorFlow==1.14.0
